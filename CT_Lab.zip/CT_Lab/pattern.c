#include<stdio.h>
int main()
{
int i,j,limit;
printf("Limit=");
scanf("%d",&limit);
for (i=1;i<=limit;i+=2)
{
for(j=1;j<=i;++j)
{
printf("* ");
}
printf("\n");
}
}
