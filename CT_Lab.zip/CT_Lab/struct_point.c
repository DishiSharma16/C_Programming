#include<stdio.h>
int main()
 {
        struct student
       {        
        char name[20];
        int rollNo;
        int age;
        float marks;  
        };      
         struct student  s1={"Harry", 254,12, 65.5};
         struct student *ptr;
         ptr=&s1;
        printf("Name\t  Roll No\t    Age\t Marks\n");
        printf("%s\t %d \t%d \t%f\n", s1.name, s1.rollNo, s1.age, s1.marks); 
        printf("%s\t %d \t%d \t%f\n", ptr->name, ptr->rollNo, ptr->age, ptr->marks);
   }


