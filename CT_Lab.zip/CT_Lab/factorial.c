#include<stdio.h>
int fac(int);
int num;
int main()
{
printf("Factorial; of a number");
printf("Enter a number=");
scanf("%d",&num);
fac();
}
int fac(int num)
int num;
{
int i=1,r=1;
while (i<=x)
{
r=i*r;
i++;
}
printf("factorial of %d=%d",x,r);
}
