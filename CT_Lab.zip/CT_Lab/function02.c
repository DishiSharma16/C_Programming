#include<stdio.h>
int square();
int main()
{
printf("Square of a number\n");
square();
printf("End of program\n");
}
int square()
{
int num;
printf("Enter a number=");
scanf("%d",&num);
printf("%d\n",num*num);
}
