#include<stdio.h>
int main()
{
float f,c;
printf("Fahrenheit=");
scanf("%f",&f);
c=(5*(f-32))/9;
printf("Fahrenheit to Celsius=%f",c);
}
