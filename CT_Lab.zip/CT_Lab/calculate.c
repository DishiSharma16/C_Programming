#include<stdio.h>
int cal();
int num1, num2,choice;
int main()
{
printf("Calculator\n");
printf("Num1=");
scanf("%d",&num1);
printf("Num2=");
scanf("%d",&num2);
printf("Your choice\n1.add\t2.subtract\t3.multiply\t4.divide\nChoice=");
scanf("%d",&choice);
cal();
}
int cal()
{
if (choice==1)
printf("Sum=%d",num1+num2);
else if (choice==2)
printf("Difference=%d",num1-num2);
else if (choice==3)
printf("Product=%d",num1*num2);
else if (choice==4)
printf("Quotient=%d",num1/num2);
}

