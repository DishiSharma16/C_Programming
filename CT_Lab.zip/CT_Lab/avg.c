#include<stdio.h>
float avg(int num[]);
int main()
{
int num[5]={1,2,3,4,5};
avg(num);
}
float avg(int num[])
{
int sum=0;
int i;
for(i=0;i<=5;i++)
{
sum+=i;
}
printf("Sum=%d\n",sum);
printf("AVERAGE=%d\n",sum/5);
}
