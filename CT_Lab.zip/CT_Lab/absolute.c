#include<stdio.h>
int absolute();
int num;
int main()
{
printf("Absolute Value\n");
printf("Enter a num=");
scanf("%d",&num);
absolute();
}
int absolute()
{
int num,ab;
printf("Absolute of %d=",num);
printf("%d",)
}
