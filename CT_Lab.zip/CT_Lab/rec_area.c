//Area of a reactangle
#include<stdio.h>
int main()
{
float l,b,area;
printf("Enter the Length of the rectangle=\n");
scanf("%f",&l);
printf("Enter the Breadth of the rectangle=\n");
scanf("%f",&b);
area=l*b;
printf("Area of the rectangle=%f\n",area);
}
