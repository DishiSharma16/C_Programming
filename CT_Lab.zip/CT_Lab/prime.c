#include<stdio.h>
int prime(int);
int num;
int main()
{
printf("Prime numbers");
printf("Enter the number=");
scanf("%d",&num);
prime();
}
int prime(num);
if num
