#include<stdio.h>
int main()
{
float l,area;
printf("Length=");
scanf("%f",&l);
area=l*l;
printf("Area=%f",area);
}
