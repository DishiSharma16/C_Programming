#include<stdio.h>
int main()
{
float r,area;
printf("Radius=");
scanf("%f",&r);
area=3.14*(r)*(r);
printf("Area of the cicle=%f",area);
}
