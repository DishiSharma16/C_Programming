#include<stdio.h>
int main()
{
printf("English=92\t");
printf("Maths=87\t");
printf("Chemistry=90\n");
printf("Physics=82\t");
printf("Computer=88\n");
}
