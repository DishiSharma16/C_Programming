#include<stdio.h>
int sum(int);
int main()
{
int lim,i;
printf("Enter the limit=");
scanf("%d",&lim);
printf("Sum=\n");
for(i=1;i<=lim;i++)
{
printf("Sum=%d",sum(i));
}
}
int sum(int i)
{
return(sum(i-1)+sum(i-2));
}
