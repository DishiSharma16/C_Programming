#include<stdio.h>
int main()
{
float hrs,rate,weeks,m_pay;

}

