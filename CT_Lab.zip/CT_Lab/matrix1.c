#include<stdio.h>
int main()
{
int matrix=
