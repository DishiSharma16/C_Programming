#include<stdio.h>
int main()
{
int num[3];
printf("Enter the nos.=");
for(int i=0;i<3;i++)
{
scanf("%d\t",&num[i]);
}
if (num[1]>num[2] && num[1]>num[3])
{
printf("Maximum no.=%d",num[1]);
}
else if (num[2]>num[1] && num[2]>num[3])
{
printf("Maximum no.=%d",num[2]);
}
else if (num[3]>num[1] && num[3]>num[2])
{
printf("Maximum no.=%d",num[3]);
}
}
