#include<stdio.h>
int main()
{
int name;
scanf("%d"&name);
printf("BOOK TITLE=%d",name);
}
