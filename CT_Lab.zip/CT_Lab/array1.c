#include<stdio.h>
int display(int marks[]);
int main()
{
int marks[5]={90,84,79,76,92};
display(marks);
}
int display(int marks[])
{
int i;
for(i=0;i<=4;i++)
{
printf("%d\t",marks[i]);
}
printf("\n");
}
