//Write a C program to print a user's height
#include<stdio.h>
int main()  //main represents starting of a program
{
int height;
printf("Enter your height=");
scanf("%d",&height);
printf("Height= %d\n",height);
}
