#include<stdio.h>
int swap();

int main()
{
printf("Swapping\n");
swap();
printf("Done!");
}
int swap()
{
int num;
printf("Enter a number=");
scanf("%d",&num);


