#include<stdio.h>
int main()
{
float p1,p2,p3,p4,p5;
float total_price;
printf("Enter the price of item1=\n");
scanf("%f",&p1);
printf("Enter the price of item2=\n");
scanf("%f",&p2);
printf("Enter the price of item3=\n");
scanf("%f",&p3);
printf("Enter the price of item4=\n");
scanf("%f",&p4);
printf("Enter the price of item5=\n");
scanf("%f",&p5);
total_price=p1+p2+p3+p4+p5;
printf("Price of Item1=%f\n",p1);
printf("Price of Item2=%f\n",p2);
printf("Price of Item3=%f\n",p3);
printf("Price of Item4=%f\n",p4);
printf("Price of Item5=%f\n",p5);
printf("Total Price=%f\n",total_price);
}
