#include<stdio.h>
int main()
{
int a;
printf("Days of the week");
printf("Enter your choice(1-7)");
scanf("%d",&a);
if (a==1)
{
printf("Monday");
}
else if input==2
{
printf("Tuesday");
}
