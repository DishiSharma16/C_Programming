#include<stdio.h>
int sum(int);
int main()
{
int n,i;
printf("Enter the number=");
scanf("%d",&n);
for //for loop
{
printf("Sum of the digits of %d=%d",n,sum(i));
}
int sum(int num)
{

