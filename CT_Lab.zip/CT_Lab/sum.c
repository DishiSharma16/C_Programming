#include<stdio.h>
int sum();
int main()
{
printf("Sum of two numbers\n");
sum();
printf("End of program");
}
int sum()
{
int num1,num2;
printf("Enter num1=");
scanf("%d",&num1);
printf("Enter num2=");
scanf("%d",&num2);
printf("%d\n",num1+num2);
}
