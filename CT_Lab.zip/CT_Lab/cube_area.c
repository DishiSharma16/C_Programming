#include<stdio.h>
int main()
{
float l,area;
printf("Dimensions of the cube=");
scanf("%f",&l);
area=6*(l)*(l);
printf("Area=%f",area);
}
