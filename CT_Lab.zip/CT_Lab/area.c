#include<stdio.h>
int area();
int peri();
int main()
{
printf("Area of a Square\n");
area();
printf("Perimeter of a Square\n");
peri();
printf("End of program");
}
int area()
{
int side;
printf("Side=");
scanf("%d",&side);
printf("%d\n",side*side);
}
int peri()
{
int side;
printf("Side=");
scanf("%d",&side);
printf("%d\n",4*side);
}

