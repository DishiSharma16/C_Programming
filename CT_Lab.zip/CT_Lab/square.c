#include<stdio.h>
int square(int);
int main()
{
int n;
printf("Enter a number=");
scanf("%d",&n);
square(n);
}
int square(int n)
{
int squ;
squ=n*n;
printf("Square of %d=%d\n",n,squ);
}

