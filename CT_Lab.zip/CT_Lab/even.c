#include<stdio.h>
int main()
{
int limit,i;
printf("Limit=");
scanf("%d",&limit);
for (i=0;i<=limit;i+=2)
{
printf("%d\t",i);
}
}
