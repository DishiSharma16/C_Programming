#include<stdio.h>
int main()
{
struct  student
{        
     char name[20];
     int rollNo;
     int age;
     float marks;  
};    
struct student s[10];  
int i;
printf("Enter the student details\n");
for (i=0;i<2;i++)
{
  scanf("%s %d %d %f", s[i].name, &s[i].rollNo, &s[i].age, &s[i].marks);
}
printf("Name\t, Roll No\t,   Age\t, Marks\n");
for (i=0;i<2;i++)
{
printf("%s\t %6d \t%6d \t%9.2f\n", s[i].name, s[i].rollNo, s[i].age,s[i].marks);
}
getchar();
}

