#include<stdio.h>
int even_odd();
int num;
int  main()
{
printf("Enter a number(even/odd)=\n");
scanf("%d",&num);
even_odd();
}
int even_odd()
{
if (num%2==0)
{
printf("Even\n");
}
else
{
printf("Odd\n");
}
}
