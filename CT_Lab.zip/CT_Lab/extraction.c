#include<stdio.h>
int main()
{
int input,digit;
printf("Enter a number=");
scanf("%d",&input);
while (input>0)
{
digit=input%10;
printf("%d",digit);
input=input/10;
}
}
